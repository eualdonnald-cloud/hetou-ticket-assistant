package com.example.hetouticketassistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.*
import android.widget.TextView
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OverlayService : Service() {
    companion object {
        const val ACTION_START = "START_OVERLAY"
        const val CHANNEL = "hetou_ticket_alerts"
        const val NOTIFICATION_ID = 42
        const val PREFS = "ticket_state"
        const val KEY_STATUS = "last_status"
    }
    private val handler = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var overlay: TextView? = null
    private var lastSlot = ""
    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
            val hm = fmt.format(now)
            val slot = when {
                hm in listOf("21:30", "22:00", "22:30", "23:00") -> "次日票放票提醒 $hm"
                hm.endsWith(":00") && (hm.substring(0, 2).toIntOrNull()?.let { it in 8..17 } == true) -> "当日票放票提醒 $hm"
                else -> ""
            }
            if (slot.isNotEmpty() && slot != lastSlot) {
                lastSlot = slot
                notifyUser(slot, "请查看河头老街官方小程序当前预约状态。")
            }
            val status = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_STATUS, "等待微信页面状态") ?: "等待微信页面状态"
            overlay?.text = "河头老街提醒\n$status\n放票时间按本机时间"
            handler.postDelayed(this, 15_000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification("监控提醒已启动"))
        if (Settings.canDrawOverlays(this)) showOverlay()
        handler.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Settings.canDrawOverlays(this) && overlay == null) showOverlay()
        return START_STICKY
    }

    private fun showOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            text = "河头老街提醒\n正在监控"
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xCC8F1D16.toInt())
            setPadding(18, 14, 18, 14)
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 220 }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        tv.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (downX - event.rawX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    windowManager?.updateViewLayout(tv, params); true
                }
                else -> true
            }
        }
        overlay = tv
        try { windowManager?.addView(tv, params) } catch (_: Exception) { overlay = null }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "河头老街预约提醒", NotificationManager.IMPORTANCE_HIGH)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun buildNotification(message: String) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle("河头老街预约提醒")
        .setContentText(message)
        .setOngoing(true)
        .build()
    private fun notifyUser(title: String, body: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(title.hashCode(), NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build())
    }
    override fun onDestroy() {
        handler.removeCallbacks(tick)
        overlay?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        overlay = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
