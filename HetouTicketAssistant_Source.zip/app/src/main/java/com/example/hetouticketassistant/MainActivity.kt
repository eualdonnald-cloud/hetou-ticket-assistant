package com.example.hetouticketassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (18 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.rgb(255, 247, 232))
        }
        fun text(s: String, size: Float = 16f) = TextView(this).apply {
            text = s; textSize = size; setTextColor(Color.rgb(75, 48, 35))
            setPadding(0, pad / 2, 0, pad / 2)
        }
        fun button(s: String, action: () -> Unit) = Button(this).apply {
            text = s; setOnClickListener { action() }
        }
        root.addView(text("河头老街预约提醒", 24f))
        root.addView(text("目标：河头老街单人预约票 · 唐山本地游客专享\n监控方式：放票时间提醒 + 微信当前页面文字变化提醒"))
        root.addView(text("说明：本工具只在手机本地运行。请在微信中手动打开正确票种和日期；发现状态变化后由你自行确认预约。"))
        root.addView(button("1. 授予悬浮窗权限") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        })
        root.addView(button("2. 开启页面变化提醒（无障碍服务）") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("3. 启动悬浮窗和放票时间提醒") {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
            }
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_START))
        })
        root.addView(button("停止悬浮窗") {
            stopService(Intent(this, OverlayService::class.java))
        })
        root.addView(text("放票时间规则（按你提供的页面提示）：\n次日票：21:30、22:00、22:30、23:00\n当日票：08:00–17:00，每个整点\n\n注意：提醒不代表有票；页面变化检测依赖微信无障碍服务能读取到的可见文字。"))
        setContentView(root)
    }
}
