package com.example.hetouticketassistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.app.NotificationManager
import androidx.core.app.NotificationCompat

class TicketAccessibilityService : AccessibilityService() {
    private var lastRelevant = ""
    private val keywords = listOf("可预约", "已约满", "售罄", "暂无票", "立即预约", "剩余", "库存", "预约成功", "不可预约")

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val parts = mutableSetOf<String>()
        collect(rootInActiveWindow, parts)
        val relevant = parts.sorted().joinToString(" | ")
        if (relevant.isNotBlank() && relevant != lastRelevant) {
            val old = lastRelevant
            lastRelevant = relevant
            getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE).edit()
                .putString(OverlayService.KEY_STATUS, relevant.take(120)).apply()
            if (old.isNotBlank()) {
                val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(77, NotificationCompat.Builder(this, OverlayService.CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("河头老街页面文字有变化")
                    .setContentText(relevant.take(160))
                    .setAutoCancel(true).build())
            }
        }
    }

    private fun collect(node: AccessibilityNodeInfo?, out: MutableSet<String>) {
        if (node == null) return
        val value = node.text?.toString()?.trim().orEmpty()
        if (value.isNotEmpty() && keywords.any { value.contains(it) }) out.add(value)
        for (i in 0 until node.childCount) collect(node.getChild(i), out)
    }
    override fun onInterrupt() {}
}
