# 河头老街预约提醒（Android Studio 项目）

这是一个本地运行的安卓辅助提醒项目骨架，采用悬浮窗 + 微信无障碍可见文字变化提醒。

## 已实现
- 悬浮窗状态面板，可拖动。
- 放票时间提醒：次日票 21:30 / 22:00 / 22:30 / 23:00；当日票 08:00–17:00 每整点。
- 可选无障碍服务：仅观察微信当前可见窗口中“可预约、已约满、售罄、暂无票、立即预约、剩余、库存、预约成功、不可预约”等文字变化。
- 状态仅保存在本机 SharedPreferences，不上传网络、不保存完整页面文本。

## 尚未实现 / 重要限制
- 这不是自动抢票器，不会自动点击购票、绕过排队/验证码/实名核验或支付。
- “页面变化提醒”受微信页面实现和无障碍可访问性限制；若小程序把库存绘制成图片、Canvas 或不可访问控件，可能检测不到。
- 放票时间提醒只是时间提醒，不代表该时刻一定有库存。
- Android 厂商的后台限制可能会停止服务；请在系统设置中允许通知和必要的后台运行。
- 无障碍权限非常敏感。只在你理解并信任本项目代码时启用；可随时在系统设置关闭。

## 构建
1. 用 Android Studio 打开项目根目录 `HetouTicketAssistant`。
2. 安装 Android SDK 35，并使用 JDK 17。
3. 等待 Gradle Sync；如提示缺少 AndroidX Core，请在 `app/build.gradle.kts` 的 dependencies 中加入：
   `implementation("androidx.core:core-ktx:1.15.0")`
   `implementation("androidx.appcompat:appcompat:1.7.0")`
4. 点击 Run 安装到 Android 手机。
5. 打开应用，依次授予悬浮窗权限、通知权限；如需页面变化提醒，再到无障碍设置开启“河头老街页面变化提醒”。
6. 回到应用，启动悬浮窗；在微信中手动进入“唐山本地游客专享”对应预约页面。

## 兼容性
- minSdk 26（Android 8.0）
- targetSdk 35
- Kotlin / Android Gradle Plugin 项目


## 手机无电脑云端编译（GitHub Actions）
1. 在手机浏览器登录 GitHub，创建一个新的 **Public** 仓库（例如 `hetou-ticket-assistant`）。
2. 在仓库首页选择 **Add file → Upload files**。先解压本项目 ZIP（手机文件管理器一般支持解压），把项目内所有文件和 `.github` 隐藏目录一并上传到仓库根目录，提交到 `main` 分支。若手机网页不便上传整个目录，可用 GitHub Desktop（需要电脑）或支持上传文件夹的移动端浏览器；不要只上传 ZIP 本身。
3. 打开仓库的 **Actions** 页面，选择 **Build Android APK** 工作流，点击 **Run workflow**（若 push 已自动触发，也可直接打开最近一次运行）。
4. 等待构建完成，打开该次运行页面底部 **Artifacts**，下载 `hetou-ticket-assistant-debug-apk`，解压得到 `app-debug.apk`。
5. 在安卓手机上点击 APK 安装。系统若提示，允许浏览器/文件管理器“安装未知应用”。

注意：云端构建需要 GitHub 账号；公开仓库意味着源码公开，但不包含你的个人信息或购票账号。若不想公开源码，创建 Private 仓库也可以，GitHub Actions 的可用额度和限制以账号当前政策为准。
